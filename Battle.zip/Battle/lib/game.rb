require './lib/player'

class Game
    attr_reader :players, :current_turn

    def initialize(player_1, player_2) 
        @players = [player_1, player_2]
        @current_turn = player_1
    end

    def attack(player)
        player.receive_damage
    end

    def swtich_turns
        @current_turn = oppenent_of(current_turn)
    end    
    
    def oppenent_of(the_player)
        @players.select { |player| player != the_player }.first
    end

end    

